from django.urls import path, include
from .views import HomeView, ArticleDetailView, Add_Post, Update_Post_View, Delete_Post_View, Add_Category, category
# from . import views
urlpatterns = [
    # path('', views.home, name='home'),
    path('', HomeView.as_view(), name="home"),
    path('article/<int:pk>', ArticleDetailView.as_view(), name="article_detail"),
    path('add_post/', Add_Post.as_view(), name="addpost"),
    path('add_category/', Add_Category.as_view(), name="addcategory"),
    path('article/update_post/<int:pk>', Update_Post_View.as_view(), name='updatepost'),
    path('article/<int:pk>/deletepost', Delete_Post_View.as_view(), name='deletepost'),
    path('category/<str:cat>', category, name="category"),
]
