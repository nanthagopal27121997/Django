from django.apps import AppConfig


class TheblohConfig(AppConfig):
    name = 'thebloh'
